# Assignment

This is the phonebook  creation in C# .The User class iS the base class,the company and user groups are sub-classes.
Used CRUD as the methods and also  applied SOLID functionalities.
To access the program
Open Visual studio 2017
